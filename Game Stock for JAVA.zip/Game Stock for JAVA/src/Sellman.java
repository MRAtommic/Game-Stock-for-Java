
//6606021631050 วีรภัทร ชื่นชอบ
import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.util.Random;

public class Sellman extends JFrame implements ActionListener {

    private JTextArea jt, jt1, jt2;
    private JScrollPane bar, bar1, bar2;
    public int m1 = 100, m2 = 150, m3 = 250, m4 = 400, money = 1000, mr1, mr2, mr3, mr4, buy1, buy2, buy3, buy4, slae1,
            slae2, slae3, slae4;
    public int valueB1 = 0, valueB2 = 0, valueB3, valueB4 = 0, valueS1 = 0, valueS2 = 0, valueS3 = 0, valueS4 = 0,
            valueme1 = 0, valueme2 = 0, valueme3 = 0,
            valueme4 = 0, day = 1;
    private JButton bday, bbuy, bslae, bgame;

    private JTextField fbuy1, fbuy2, fbuy3, fbuy4, fslae1, fslae2, fslae3, fslae4;
    private JLabel lday, lmoney, lvalueme;
    private String ms1 = "", ms2 = "", ms3 = "", ms4 = "";

    public Sellman() {

        super("Sellman");
        JPanel jpanel = new JPanel(new FlowLayout());

        jpanel.setBackground(Color.BLUE);

        String list[] = { "JAVA", "C++", "HTML", "PYTHON" };

        lday = new JLabel("[ Day : " + day + " ]");

        lmoney = new JLabel("[ Money = " + money + " $ ]");

        jt = new JTextArea(15, 65);
        bar = new JScrollPane(jt);

        bday = new JButton("New_Day");
        bday.addActionListener(this);

        lday.setForeground(Color.WHITE);
        lmoney.setForeground(Color.WHITE);

        fbuy1 = new JTextField(5);
        fbuy2 = new JTextField(5);
        fbuy3 = new JTextField(5);
        fbuy4 = new JTextField(5);

        fbuy1.setText("0");
        fbuy2.setText("0");
        fbuy3.setText("0");
        fbuy4.setText("0");

        bbuy = new JButton("Buy");
        bbuy.addActionListener(this);

        jt1 = new JTextArea(10, 45);
        bar1 = new JScrollPane(jt1);

        jt2 = new JTextArea(10, 20);
        bar2 = new JScrollPane(jt2);

        jt.setBackground(Color.BLACK);
        jt1.setBackground(Color.BLACK);
        jt2.setBackground(Color.BLACK);

        jt.setForeground(Color.GREEN);
        jt1.setForeground(Color.GREEN);
        jt2.setForeground(Color.GREEN);

        fslae1 = new JTextField(5);
        fslae2 = new JTextField(5);
        fslae3 = new JTextField(5);
        fslae4 = new JTextField(5);

        fslae1.setText("0");
        fslae2.setText("0");
        fslae3.setText("0");
        fslae4.setText("0");

        bslae = new JButton("Sell");
        bslae.addActionListener(this);

        lvalueme = new JLabel(
                "[ Value = [" + valueme1 + "]" + "[" + valueme2 + "]" + "[" + valueme3 + "]" + "[" + valueme4 + "]"
                        + " ]");

        lvalueme.setForeground(Color.WHITE);

        jpanel.add(lday);
        jpanel.add(lmoney);
        jpanel.add(lvalueme);
        jpanel.add(bday);
        jpanel.add(bar);
        jpanel.add(fbuy1);
        jpanel.add(fbuy2);
        jpanel.add(fbuy3);
        jpanel.add(fbuy4);
        jpanel.add(bbuy);
        jpanel.add(bar1);
        jpanel.add(bar2);
        jpanel.add(fslae1);
        jpanel.add(fslae2);
        jpanel.add(fslae3);
        jpanel.add(fslae4);
        jpanel.add(bslae);

        add(jpanel);

        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

    }

    public void check() {
        if (m1 > mr1)
            ms1 = "▲";
        else if (m1 < mr1)
            ms1 = "▽";
        else
            ms1 = "▶◀";

        if (m1 > mr1)
            ms1 = "▲";
        else if (m1 < mr1)
            ms1 = "▽";
        else
            ms1 = "▶◀";

        if (m2 > mr2)
            ms2 = "▲";
        else if (m2 < mr2)
            ms2 = "▽";
        else
            ms2 = "▶◀";

        if (m3 > mr3)
            ms3 = "▲";
        else if (m3 < mr3)
            ms3 = "▽";
        else
            ms3 = "▶◀";

        if (m4 > mr4)
            ms4 = "▲";
        else if (m4 < mr4)
            ms4 = "▽";
        else
            ms4 = "▶◀";
    }

    public void random() {
        Random ran = new Random();
        if (m1 > 0) {
            mr1 = m1;
            m1 += ran.nextInt(-12, 12);
        }
        if (m2 > 0) {
            mr2 = m2;
            m2 += ran.nextInt(-5, 5);
        }
        if (m2 > 0) {
            mr3 = m3;
            m3 += ran.nextInt(-4, 4);
        }
        if (m4 > 0) {
            mr4 = m4;
            m4 += ran.nextInt(-18, 18);
        }

        if (m1 <= 0) {
            mr1 = m1;
            m1 += ran.nextInt(25, 30);
        }
        if (m2 <= 0) {
            mr2 = m2;
            m2 += ran.nextInt(25, 30);
        }
        if (m2 <= 0) {
            mr3 = m3;
            m3 += ran.nextInt(25, 30);
        }
        if (m4 <= 0) {
            mr4 = m4;
            m4 += ran.nextInt(25, 30);
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String str = e.getActionCommand();

        random();

        if (day == 200) {
            if (money >= 5000) {
                JOptionPane.showMessageDialog(null, "YOU WIN");
            } else if (money < 5000) {
                JOptionPane.showMessageDialog(null, "YOU Dog");
            }
        }

        if (day == 1 && str.equals("New_Day")) {
            for (int i = 0; i < 10; i++) {

                random();
                check();
                jt.append(
                        "JAVA = " + m1 + "[" + ms1 + "]" + "\t\t" + "C++ = " + m2 + "[" + ms2 + "]" + "\t\t" + "HTML = "
                                + m3 + "[" + ms3 + "]" + "\t\t" + "Python = " + m4 + "[" + ms4 + "]" + "\n\n");
            }

        }

        check();

        if (str.equals("New_Day")) {

            day += 1;
            lday.setText("[ Day : " + day + " ]");
            jt.append("JAVA = " + m1 + "[" + ms1 + "]" + "\t\t" + "C++ = " + m2 + "[" + ms2 + "]" + "\t\t" + "HTML = "
                    + m3 + "[" + ms3 + "]" + "\t\t" + "Python = " + m4 + "[" + ms4 + "]" + "\n\n");
            fbuy1.setText("0");
            fbuy2.setText("0");
            fbuy3.setText("0");
            fbuy4.setText("0");

            fslae1.setText("0");
            fslae2.setText("0");
            fslae3.setText("0");
            fslae4.setText("0");

        } else if (str.equals("Buy")) {
            valueB1 = Integer.parseInt(fbuy1.getText());
            valueB2 = Integer.parseInt(fbuy2.getText());
            valueB3 = Integer.parseInt(fbuy3.getText());
            valueB4 = Integer.parseInt(fbuy4.getText());

            buy1 = valueB1 * m1;
            buy2 = valueB2 * m2;
            buy3 = valueB3 * m3;
            buy4 = valueB4 * m4;

            if (money >= (buy1 + buy2 + buy3 + buy4)) {

                lday.setText("[ Day : " + day + " ]");
                money = money - (buy1 + buy2 + buy3 + buy4);
                lmoney.setText("[ Money = " + money + " $ ]");

                valueme1 += valueB1;
                valueme2 += valueB2;
                valueme3 += valueB3;
                valueme4 += valueB4;

                if (valueB1 > 0) {
                    jt1.append(
                            "Pirce Java = " + m1 + "\n" + "Buy = " + "-" + buy1 + "\n" + "Value = " + valueB1 + "\n"
                                    + "==============" + "\n");
                }

                if (valueB2 > 0) {
                    jt1.append(
                            "Pirce C++ = " + m2 + "\n" + "Buy = " + "-" + buy2 + "\n" + "Value = " + valueB2 + "\n"
                                    + "==============" + "\n");
                }

                if (valueB3 > 0) {
                    jt1.append(
                            "Pirce HTML = " + m3 + "\n" + "Buy = " + "-" + buy3 + "\n" + "Value = " + valueB3 + "\n"
                                    + "==============" + "\n");
                }

                if (valueB4 > 0) {
                    jt1.append(
                            "Pirce Python = " + m4 + "\n" + "Buy = " + "-" + buy4 + "\n" + "Value = " + valueB4 + "\n"
                                    + "==============" + "\n");
                }

                if ((valueB1 + valueB2 + valueB3 + valueB4) > 0) {
                    jt2.append(
                            "=====Value=====\n" + "1.JAVA     = " + valueme1 + "\n" + "2.C++      = " + valueme2
                                    + "\n"
                                    + "2.HTML   = " + valueme3 + "\n" + "4.Python = " + valueme4 + "\n"
                                    + "===============" + "\n\n\n\n");

                    jt.append("JAVA = " + m1 + "[" + ms1 + "]" + "\t\t" + "C++ = " + m2 + "[" + ms2 + "]" + "\t\t"
                            + "HTML = "
                            + m3 + "[" + ms3 + "]" + "\t\t" + "Python = " + m4 + "[" + ms4 + "]" + "\n\n");

                }

                lvalueme.setText("[ Value = [" + valueme1 + "]" + "[" + valueme2 + "]" + "[" + valueme3 + "]" + "["
                        + valueme4 + "]" + " ]");

            }

        } else if (str.equals("Sell")) {
            valueS1 = Integer.parseInt(fslae1.getText());
            valueS2 = Integer.parseInt(fslae2.getText());
            valueS3 = Integer.parseInt(fslae3.getText());
            valueS4 = Integer.parseInt(fslae4.getText());

            slae1 = valueS1 * m1;
            slae2 = valueS2 * m2;
            slae3 = valueS3 * m3;
            slae4 = valueS4 * m4;

            if ((valueS1 <= valueme1) && (valueS2 <= valueme2) && (valueS3 <= valueme3) && (valueS4 <= valueme4)) {

                day += 1;
                lday.setText("[ Day : " + day + " ]");

                valueme1 -= valueS1;
                valueme2 -= valueS2;
                valueme3 -= valueS3;
                valueme4 -= valueS4;

                money += slae1;
                money += slae2;
                money += slae3;
                money += slae4;

                lmoney.setText("[ Money = " + money + " $ ]");

                if (valueS1 > 0) {
                    jt1.append(
                            "" + "Pirce JAVA = " + m1 + "\n" + "Sell = " + "+" + slae1 + "\n" + "Value = " + valueS1 +
                                    "\n===============" + "\n");
                }

                if (valueS2 > 0) {
                    jt1.append(
                            "" + "Pirce C++ = " + m2 + "\n" + "Sell = " + "+" + slae2 + "\n" + "Value = " + valueS2 +
                                    "\n===============" + "\n");
                }

                if (valueS3 > 0) {
                    jt1.append(
                            "" + "Pirce HTML = " + m3 + "\n" + "Sell = " + "+" + slae3 + "\n" + "Value = " + valueS3 +
                                    "\n===============" + "\n");
                    ;
                }

                if (valueS4 > 0) {
                    jt1.append(
                            "" + "Pirce Python = " + m4 + "\n" + "Sell = " + "+" + slae4 + "\n" + "Value = " + valueS4 +
                                    "\n===============" + "\n");
                }
                if ((valueS1 + valueS2 + valueS3 + valueS4) > 0) {
                    jt2.append(
                            "=====Value=====\n" + "1.JAVA     = " + valueme1 + "\n" + "2.C++      = " + valueme2
                                    + "\n"
                                    + "2.HTML   = " + valueme3 + "\n" + "4.Python = " + valueme4 + "\n"
                                    + "===============" + "\n\n\n\n");

                    jt.append("JAVA = " + m1 + "[" + ms1 + "]" + "\t\t" + "C++ = " + m2 + "[" + ms2 + "]" + "\t\t"
                            + "HTML = "
                            + m3 + "[" + ms3 + "]" + "\t\t" + "Python = " + m4 + "[" + ms4 + "]" + "\n\n\n");

                }
                lvalueme.setText("\n[ Value = [" + valueme1 + "]" + "[" + valueme2 + "]" + "[" + valueme3 + "]" + "["
                        + valueme4 + "]" + " ]");

            }

        }

    }

    public static void main(String[] args) {
        new Sellman();
    }
}
